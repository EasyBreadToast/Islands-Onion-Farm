import cv2 as cv
import numpy as np
import os
import pyautogui
from time import time, sleep
from windowcapture import WindowCapture
from detection import Detection
from vision import Vision
from threading import Thread
from pywinauto.keyboard import send_keys

# Change the working directory to the folder this script is in.
# Doing this because I'll be putting the files from each video in their own folder on GitHub
os.chdir(os.path.dirname(os.path.abspath(__file__)))

DEBUG = True

# initialize/load these
wincap = WindowCapture('Roblox')
detector = Detection('cascade.xml')
vision = Vision()

#StartPlug for bot actions
is_bot_in_action = False

def bot_actions(reactangles):

    print("Bot thread started")
    
    print("OOOOOOOF")
    if len(detector.rectangles) > 0:
        pyautogui.PAUSE = 0.001
        targets = vision.get_click_points(detector.rectangles)
        target = wincap.get_screen_position(targets[0])
        pyautogui.click(x=target[0], y=target[1])
        send_keys("{F down}")
        for clicks in range(130):
            pyautogui.click()
        send_keys("{F up}")

        pyautogui.click(1900,-1000)
    else:
        print("No Onions, Moving.wd")
        pyautogui.move(-100, 100)
        pyautogui.click()
        send_keys('{S down}')
        sleep(.1)
        send_keys('{S up}')
        pyautogui.click(1900,-1000)


    global is_bot_in_action
    is_bot_in_action = False

    


#Start wincap, detector, and botf
wincap.start() 
detector.start()


while(True):

    if wincap.screenshot is None:
        continue
    
    # give detector the current screenshot to search for objects in
    detector.update(wincap.screenshot)


    if not is_bot_in_action:
        is_bot_in_action = True
        t = Thread(target=bot_actions, args=(detector.rectangles,))
        t.start()


    if DEBUG:
        detection_image = vision.draw_rectangles(wincap.screenshot, detector.rectangles)
        cv.imshow('Computer Vision', detection_image)

    # press 'q' with the output window focused to exit.
    # waits 1 ms every loop to process key presses
    if cv.waitKey(1) == ord('q'):
        wincap.stop()
        detector.stop()
        cv.destroyAllWindows()
        break

print('Done.')
